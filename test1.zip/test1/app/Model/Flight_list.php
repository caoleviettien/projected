<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Flight_list extends Model
{
    protected $table = 'flight_list';
    protected $primaryKey = 'id';
}
